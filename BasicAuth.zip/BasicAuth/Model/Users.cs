using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BasicAuth.Model
{
    public class Users
    {
        public int Id { get; set; }
        public string? User { get; set; }
        public string? Pwd { get; set; }
        public int Grupoid { get; set; }
        public int Key { get; set; }
        public string? Email { get; set; }
        public bool Status { get; set; }

        public void LimparSenha()
        {
            Pwd = "";
        }
    }
}