public class Login
{
    public string UserName { get; set; } = "";
    public string Pwd { get; set; } = "";
}
