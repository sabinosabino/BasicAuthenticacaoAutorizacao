using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Models.DTO
{
    public class AlterarSenha
    {
        public string Login { get; set; }
        public string ?SenhaAtual { get; set; }
        public string ?NovaSenha { get; set; }
        public string ?ConfirmacaoNovaSenha { get; set; }

        private const int ComprimentoMinimoSenha = 8;

        // Método para validar a troca de senha
        public bool ValidarTrocaSenha(out string mensagemErro)
        {
            mensagemErro = string.Empty;

            if (string.IsNullOrWhiteSpace(Login))
            {
                mensagemErro = "O login não pode estar vazio.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(SenhaAtual))
            {
                mensagemErro = "A senha atual não pode estar vazia.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(NovaSenha))
            {
                mensagemErro = "A nova senha não pode estar vazia.";
                return false;
            }

            if (NovaSenha != ConfirmacaoNovaSenha)
            {
                mensagemErro = "A nova senha e a confirmação não coincidem.";
                return false;
            }

            if (NovaSenha == SenhaAtual)
            {
                mensagemErro = "A nova senha não pode ser igual à senha atual.";
                return false;
            }

            if (!ValidarRequisitosSenha(NovaSenha))
            {
                mensagemErro = "A nova senha não atende aos requisitos mínimos de segurança. Deve ter no mínimo 8 caracteres, letra maiúscula e minúscula e caracter especial.";
                return false;
            }

            return true;
        }

        // Método para verificar requisitos mínimos de segurança da senha
        private bool ValidarRequisitosSenha(string senha)
        {
            if (senha.Length < ComprimentoMinimoSenha)
                return false;

            bool contemMaiuscula = Regex.IsMatch(senha, "[A-Z]");
            bool contemMinuscula = Regex.IsMatch(senha, "[a-z]");
            bool contemDigito = Regex.IsMatch(senha, "[0-9]");
            bool contemEspecial = Regex.IsMatch(senha, "[^a-zA-Z0-9]");

            return contemMaiuscula && contemMinuscula && contemDigito && contemEspecial;
        }
    }
}