using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BasicAuth.Model;
using ControleArquivo.Services;
using LibLogin;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Models.DTO;

namespace BasicAuth.Controller
{
    [ApiController]
    [Route("api/[controller]")]
 public class UserController:ControllerBase
    {
        [AllowAnonymous]
        [HttpPost("Logar")]
        public async Task<ActionResult> Logar([FromBody] Login login)
        {
            try
            {
                if (login.UserName == "admin"
                    & login.Pwd == "1234")
                {
                    var service = ServiceStatic.GetService();
                    var result = await service.Registrar<UserRegister>("","admin","admin","admin","admin","1","22",this.HttpContext);
                    string[]rotas = ["RotaA","RotaB","RotaC"];
                    await service.RegistrarRotasBloqueadas(rotas,result.Token);
                    return Ok(result);
                }
                else
                {
                    return BadRequest(new{erro="Login ou senha inválidos"});
                }
            }
            catch (System.Exception e)
            {
                return BadRequest(new { Erro = e.Message });
            }
        }

        [Permissao]
        [HttpPost("alterar")]
        public async Task<ActionResult> AlterarSenha([FromBody] AlterarSenha m)
        {
            try
            {
                if (m is null)
                    throw new Exception("Login was not given");


                if (m.ValidarTrocaSenha(out string mensagemErro))
                {
                    string parseSenha = "";

                    //Pega usuário
                    //valida se user é null

                    var login = new Users();
                    login.Pwd = "XPUSRQWPUSRQVPUSRQUPUSRQ";
                    login.Key = 123456;
                    
                    if (login == null)
                        throw new Exception("Usuário não encontrado");


                    string senhaCriptografada = Crypt.Services.Crypt.fncCrip(m.SenhaAtual, login.Key); //"key do objeto user"

                    if (!login.Pwd.Equals(senhaCriptografada))
                    {
                        throw new Exception("Senha atual fornecida não é igual a cadastrada");
                    }

                    login.Key = 654321;
                    string senhacrip = Crypt.Services.Crypt.fncCrip(m.NovaSenha, login.Key);
                    login.Pwd = senhacrip;

                    //Alterar a senha

                    return Ok("Registro alterado com sucesso");
                }
                else
                {
                    throw new Exception(mensagemErro);
                }
            }
            catch (Exception e)
            {
                return BadRequest(new{erro=e.Message});
            }
        }

        [AllowAnonymous]
        [HttpPost("Recuperar/{login}")]
        public async Task<ActionResult<string>> Recuperar(string login)
        {
            try
            {
                //pega no repository
                var user = new Users();
                user.Email = "sabinowelbert@@@";

                if (user == null)
                    return BadRequest("Login não encontrado");

                user.Pwd = Crypt.Services.Crypt.GerarSenhaAleatoria(8);
                var tempsemha = user.Pwd;
                user.Key = 654321;
                user.Pwd = Crypt.Services.Crypt.fncCrip(tempsemha, user.Key);

                //Altear User
                
                var result = new Email("Recuperação Senha", "Sua senha de recuperação será: " + tempsemha, user.Email).SendEmail();
                return Ok("Recuperação de senha enviado para :" + user.Email);
            }
            catch (Exception e)
            {
                return BadRequest("Email não encontrado");
            }
        }

        [Permissao]
        [HttpPost("teste")]
        public async Task<ActionResult<string>> Teste()
        {
            try
            {
               return Ok();
            }
            catch (Exception e)
            {
                return BadRequest("Email não encontrado");
            }
        }
    }
}