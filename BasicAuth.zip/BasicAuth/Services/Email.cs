﻿using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;

namespace ControleArquivo.Services
{
    public class Email
    {
        string pHost = "smtp.hostinger.com";
        int pPort = 465;
        string ptitle = "";
        string pText = "";
        string[] pEmails;
        public Email(string title, string text, string emails)
        {
            ptitle = title;
            pText = text;
            pEmails = emails.Split(',');
        }
        public async Task SendEmail()
        {
            try
            {
                var message = new MimeMessage();
                message.From.Add(new MailboxAddress("", "sua conta"));

                foreach (var item in pEmails)
                {
                    message.To.Add(new MailboxAddress("",item));
                }

                message.Subject = ptitle;

                var bodyBuilder = new BodyBuilder();
                bodyBuilder.TextBody = pText;

                message.Body = bodyBuilder.ToMessageBody();

                using (var client = new MailKit.Net.Smtp.SmtpClient())
                {
                    await client.ConnectAsync(pHost, pPort, SecureSocketOptions.SslOnConnect);
                    await client.AuthenticateAsync("seu email", "sua senha");
                    await client.SendAsync(message);
                    await client.DisconnectAsync(true);
                }

                Console.WriteLine("Email enviado com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        public async Task SendEmailHtml(string caminho)
        {
            try
            {
                var message = new MimeMessage();
                message.From.Add(new MailboxAddress("", "sua conta"));

                foreach (var item in pEmails)
                {
                    message.To.Add(new MailboxAddress("", item));
                }

                message.Subject = ptitle;

                var bodyBuilder = new BodyBuilder();
                bodyBuilder.HtmlBody = pText; // Corpo do e-mail em formato HTML

                if (System.IO.File.Exists(caminho))
                {
                    using (var fileStream = File.OpenRead(caminho))
                    {
                        var memoryStream = new MemoryStream();
                        await fileStream.CopyToAsync(memoryStream);
                        memoryStream.Seek(0, SeekOrigin.Begin);

                        var attachment = new MimePart("application", "octet-stream")
                        {
                            Content = new MimeContent(memoryStream),
                            ContentDisposition = new ContentDisposition(ContentDisposition.Attachment),
                            ContentTransferEncoding = ContentEncoding.Base64,
                            FileName = Path.GetFileName(caminho)
                        };

                        bodyBuilder.Attachments.Add(attachment);
                    }
                }

                message.Body = bodyBuilder.ToMessageBody();

                using (var client = new MailKit.Net.Smtp.SmtpClient())
                {
                    await client.ConnectAsync(pHost, pPort, SecureSocketOptions.SslOnConnect);
                    await client.AuthenticateAsync("sua conta", "sua senha");
                    await client.SendAsync(message);
                    await client.DisconnectAsync(true);
                }

                //Console.WriteLine("Email enviado com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

    }
}
