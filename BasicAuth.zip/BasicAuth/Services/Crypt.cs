﻿using System.Text;

namespace Crypt.Services
{
    public static class Crypt
    {
        public static string fncCrip(string Senha, int chave)
        {
            int i;
            string sTemp = "";
            for (i = 0; i < Senha.Length; i++)
            {
                sTemp += char.Parse(Senha[i].ToString()) + chave;
            }
            string result = fncMudarparaChar(fncInvert(sTemp));
            return result;
        }

        public static string fncMudarparaChar(string texto)
        {
            StringBuilder sb = new StringBuilder();

            foreach (char c in texto)
            {
                int asciiCode = int.Parse(c.ToString()) + 80;
                char caracter = Convert.ToChar(asciiCode);
                sb.Append(caracter);
            }
            return sb.ToString();
        }

        private static string fncInvert(string Texto)
        {
            string sTemp = "";
            for (int x = Texto.Length - 1; x >= 0; x--)
            {
                sTemp += Texto[x];
            }
            return sTemp;
        }

        public static string fncChave()
        {
            string sTemp = "";
            Random random = new Random();
            for (int i = 0; i < 6; i++)
            {
                int num = random.Next(0, 8);
                if (num == 0)
                {
                    num = 1;
                }
                sTemp += num.ToString();
            }
            return sTemp;
        }

        public static string GerarSenhaAleatoria(int comprimento)
        {
            const string caracteresPermitidos = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789*#!@"; //!@#$%^&*()_+-=[]{}|;:,.<>?
            StringBuilder senha = new StringBuilder();

            Random random = new Random();

            for (int i = 0; i < comprimento; i++)
            {
                int indice = random.Next(0, caracteresPermitidos.Length);
                senha.Append(caracteresPermitidos[indice]);
            }

            return senha.ToString();
        }


    }
}
